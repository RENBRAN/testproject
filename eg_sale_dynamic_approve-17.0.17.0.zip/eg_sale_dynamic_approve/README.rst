=================================
Sale Dynamic Approve
=================================
This application is used to set the more then one person to make sale quotation approve, to set the flow for approval, set the approve team for approve quotation.
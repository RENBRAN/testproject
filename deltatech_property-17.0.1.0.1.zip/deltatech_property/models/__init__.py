# ©  2015-2019 Deltatech
#              Dorin Hongu <dhongu(@)gmail(.)com
# See README.rst file on addons root folder for license details

from . import property_abstract
from . import property_building
from . import property_config
from . import property_land
from . import property_room
from . import res_partner
